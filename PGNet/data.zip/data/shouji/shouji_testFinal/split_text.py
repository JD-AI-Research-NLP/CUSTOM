import jieba

result = list()
with open('./testFinal.text', 'r') as f:
  for i in f:
    result.append(' '.join(jieba.lcut(i.strip())))
with open('./target.text', 'w') as f:
  for i in result:
    f.write(i + '\n')
