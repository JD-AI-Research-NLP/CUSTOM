import jieba

result = list()
with open('./testFinal.prediction.writing1', 'r') as f:
  for i in f:
    buf = ''.join(i.strip().split())
    result.append(buf)
with open('./predict.text', 'w') as f:
  for i in result:
    f.write(' '.join(i) + '\n')
result2 = list()
with open('./testFinal.text', 'r') as f:
  for i in f:
    result2.append(i.strip())
with open('./target.text', 'w') as f:
  for i in result2:
    f.write(' '.join(i) + '\n')
